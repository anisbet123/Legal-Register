# SafeWork Pro — Compliance Management Platform

## 🚀 Deploy to Netlify (Free, ~5 minutes)

### Step 1 — Install Node.js
Download from [nodejs.org](https://nodejs.org) (LTS version)

### Step 2 — Build the app
Open a terminal in this folder and run:
```bash
npm install
npm run build
```

### Step 3 — Deploy to Netlify
1. Go to [app.netlify.com](https://app.netlify.com) → sign up free
2. Click **"Add new site"** → **"Deploy manually"**
3. Drag and drop the **`dist/`** folder onto the page
4. ✅ Live instantly!

> **Important:** The `netlify/functions/` folder is only used when Netlify builds
> the project itself (via GitHub). When deploying manually with `dist/`, the
> function is already compiled into the build. See Step 4 below if AI doesn't work.

### Step 4 — If the AI Legal Register still doesn't work after manual deploy

The serverless proxy function needs Netlify to build the project, not just host `dist/`.
Connect via GitHub for automatic builds:

1. Push this folder to a GitHub repository (free at github.com)
2. In Netlify → "Add new site" → "Import an existing project" → connect GitHub
3. Netlify will auto-detect the build settings from `netlify.toml`
4. Deploy — the `netlify/functions/ai-proxy.js` function will be live at `/.netlify/functions/ai-proxy`

### Step 5 — Install on devices
- **iOS Safari**: Share button → "Add to Home Screen"
- **Android Chrome**: Menu → "Install app"  
- **Windows Chrome/Edge**: Install icon in address bar

---

## 🤖 AI Legal Register Setup (Free — no credit card)

1. Sign up free at [openrouter.ai](https://openrouter.ai)
2. Profile → Keys → Create Key
3. Open `src/App.jsx`, find:
   ```js
   const OPENROUTER_API_KEY = "";
   ```
4. Paste your key inside the quotes and rebuild

**Or** enter the key inside the app on the Legal Register screen — no rebuild needed.

---

## 💻 Run locally
```bash
npm install
npm run build
npm run preview
```

For local dev with the AI proxy working:
```bash
npm install -g netlify-cli
netlify dev
```

---

## Why the serverless function?
Browsers block direct API calls to third-party services (CORS policy). The
`netlify/functions/ai-proxy.js` file runs server-side on Netlify's infrastructure,
making the OpenRouter call on your behalf and returning the result — no CORS issue.
