// Netlify serverless function — proxies OpenRouter API calls server-side.
// Automatically tries multiple free models if one is rate-limited (429).

// Free models tried in order. Skips to next on rate limit automatically.
const FREE_MODELS = [
  "meta-llama/llama-3.3-70b-instruct:free",
  "mistralai/mistral-small-3.1-24b-instruct:free",
  "google/gemma-3-27b-it:free",
  "nvidia/llama-3.1-nemotron-nano-8b-v1:free",
  "qwen/qwen3-8b:free",
];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function callModel(model, key, messages, max_tokens, temperature, origin) {
  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${key.trim()}`,
      "HTTP-Referer": origin || "https://safeworkpro.netlify.app",
      "X-Title": "SafeWork Pro",
    },
    body: JSON.stringify({
      model,
      max_tokens: max_tokens || 1500,
      temperature: temperature ?? 0.1,
      messages,
    }),
  });
  const data = await response.json();
  return { status: response.status, data };
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
      },
      body: "",
    };
  }

  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return {
      statusCode: 400,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Invalid JSON body" }),
    };
  }

  const { key, messages, max_tokens, temperature } = body;

  if (!key || !messages) {
    return {
      statusCode: 400,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Missing API key or messages" }),
    };
  }

  const origin = event.headers?.origin || event.headers?.referer || "https://safeworkpro.netlify.app";
  let lastError = "All free models are currently rate-limited. Please wait a minute and try again.";

  for (let i = 0; i < FREE_MODELS.length; i++) {
    const model = FREE_MODELS[i];
    try {
      const { status, data } = await callModel(model, key, messages, max_tokens, temperature, origin);

      // Rate limited or server error — try next model
      if (status === 429 || (status >= 500 && status < 600)) {
        lastError = `${model} returned ${status}, trying next model...`;
        if (i < FREE_MODELS.length - 1) await sleep(400);
        continue;
      }

      // Bad API key — no point trying other models
      if (status === 401 || status === 403) {
        return {
          statusCode: status,
          headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
          body: JSON.stringify({ error: "Invalid API key. Please check your OpenRouter key." }),
        };
      }

      const result = data?.choices?.[0]?.message?.content;
      if (!result) {
        lastError = `${model} returned empty content`;
        continue;
      }

      // Success
      return {
        statusCode: 200,
        headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ result, model_used: model }),
      };

    } catch (err) {
      lastError = `${model} error: ${err.message}`;
      if (i < FREE_MODELS.length - 1) await sleep(400);
      continue;
    }
  }

  // All models exhausted
  return {
    statusCode: 429,
    headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
    body: JSON.stringify({ error: lastError }),
  };
};
